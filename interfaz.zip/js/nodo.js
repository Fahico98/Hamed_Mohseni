function Nodo(cedula){
    this.cedula = cedula;
    this.izquierda = null;
    this.derecha = null;
  }