$(document).ready(() =>{
    

    $('#frmAgregarConcierto').submit((event) => {
        event.preventDefault();

        let nombre = $('#nombre').val();
        let lugar = $('#lugar').val();
        let fecha = $('#fecha').val();
        let hora = $('#hora').val();
        
        let concierto = {
            nombre: nombre,
            lugar: lugar,
            fecha: fecha,
            hora: hora
        };

        let listaConciertos = new Lista();
        listaConciertos.insertar(concierto);

        $.ajax({
            url: 'backend/crear_concierto.php',
            type: 'post',
            data: listaConciertos.buscarPorIndice(0).dato
        }).done((data) => {
            console.log(data);
        }).fail((data) => {
            console.log('fail', data);
        })
    });
});


class NodoLista{
    constructor(dato, siguiente = null){
        this.dato = dato,
        this.siguiente = siguiente
    }
}

class Lista{
    constructor(){
        this.cabeza = null;
    }
}

Lista.prototype.insertar = function(dato){
    let nodoNuevo = new NodoLista(dato);
    
    nodoNuevo.siguiente = this.cabeza;
        
    this.cabeza = nodoNuevo;
    return this.cabeza;
}

Lista.prototype.buscarPorIndice = function(indice){
    let contador = 0;
    let nodo = this.cabeza;
    while (nodo) {
        if (contador === indice) {
           return nodo;
        }
        contador++;
        nodo = nodo.siguiente;
    }
    return null;
}
